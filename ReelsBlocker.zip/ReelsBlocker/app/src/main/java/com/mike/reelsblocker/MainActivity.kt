package com.mike.reelsblocker

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/** Minimal settings screen built in code (no layout XML, no library dependencies). */
class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private lateinit var enableButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = getString(R.string.app_name)

        val pad = dp(20)
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        statusText = TextView(this).apply {
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
        }
        column.addView(statusText)

        column.addView(TextView(this).apply {
            text = "Blocks Instagram's Reels and Explore tabs by sending you back to Home. " +
                "Messages and notifications keep working."
            setPadding(0, dp(8), 0, dp(16))
        })

        enableButton = Button(this).apply {
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        column.addView(enableButton)

        column.addView(sectionLabel("What to block"))
        column.addView(toggle("Reels tab", Prefs.BLOCK_REELS, null))
        column.addView(toggle("Explore tab", Prefs.BLOCK_EXPLORE,
            "Also stops searching for new accounts via Explore."))
        column.addView(toggle("Reels opened from messages (experimental)", Prefs.BLOCK_DM_REELS,
            "Closes the full-screen reel player when no tab bar is showing. " +
                "May also close reels opened from a profile."))

        column.addView(sectionLabel("Troubleshooting"))
        column.addView(toggle("Debug logging", Prefs.DEBUG_LOG,
            "Logs Instagram's tab IDs to logcat (tag: ReelsBlocker) so the matching rules can be fixed after an Instagram update."))

        setContentView(ScrollView(this).apply { addView(column) })
    }

    override fun onResume() {
        super.onResume()
        val on = isServiceEnabled()
        statusText.text = if (on) "Blocker is ON" else "Blocker is OFF"
        enableButton.text = if (on) "Open accessibility settings" else "Turn on in accessibility settings"
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = ComponentName(this, BlockerService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(me, ignoreCase = true) }
    }

    private fun toggle(label: String, key: String, hint: String?): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        box.addView(Switch(this).apply {
            text = label
            isChecked = Prefs.flag(this@MainActivity, key)
            setOnCheckedChangeListener { _, checked ->
                Prefs.get(this@MainActivity).edit().putBoolean(key, checked).apply()
            }
        })
        if (hint != null) {
            box.addView(TextView(this).apply {
                text = hint
                textSize = 12f
                gravity = Gravity.START
            })
        }
        return box
    }

    private fun sectionLabel(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(24), 0, dp(4))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
