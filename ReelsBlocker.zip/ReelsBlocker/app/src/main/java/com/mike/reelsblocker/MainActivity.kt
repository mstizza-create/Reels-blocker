package com.mike.reelsblocker

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Minimal settings screen built in code (no layout XML, no library dependencies). */
class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private lateinit var enableButton: Button
    private lateinit var captureInfo: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = getString(R.string.app_name)

        val pad = dp(20)
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        statusText = TextView(this).apply {
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
        }
        column.addView(statusText)

        column.addView(TextView(this).apply {
            text = "Blocks Instagram's Reels and Explore tabs by sending you back to Home. " +
                "Messages and notifications keep working."
            setPadding(0, dp(8), 0, dp(16))
        })

        enableButton = Button(this).apply {
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        column.addView(enableButton)

        column.addView(sectionLabel("Mode"))
        column.addView(toggle("Messages only", Prefs.MESSAGES_ONLY,
            "Whenever Home, Reels, Search or Profile is selected in Instagram, jumps straight to " +
                "Messages. While this is on, the two Home feed options below do nothing."))

        column.addView(sectionLabel("Home feed"))
        column.addView(toggle("Open Home on Following feed", Prefs.AUTO_FOLLOWING,
            "Each time you open Instagram, switches Home to Following (only people you follow, " +
                "no suggested posts). You may see a brief flicker while it does this."))

        column.addView(toggle("Black out Home feed below stories", Prefs.BLACKOUT_HOME,
            "On the normal Home feed, covers the posts and reels under the story row with black. " +
                "Use the Following feed to browse posts. The black layer can lag slightly while you scroll."))

        column.addView(sectionLabel("What to block"))
        column.addView(toggle("Reels tab", Prefs.BLOCK_REELS, null))
        column.addView(toggle("Explore tab", Prefs.BLOCK_EXPLORE,
            "Also stops searching for new accounts via Explore."))
        column.addView(toggle("Close full-screen reel player (experimental)", Prefs.BLOCK_DM_REELS,
            "Presses Back when a full-screen player is open with no tab bar. " +
                "Can also catch Stories, so leave this off unless you are testing."))

        column.addView(sectionLabel("Capture mode (for fixing the rules)"))
        column.addView(toggle("Capture mode", Prefs.CAPTURE,
            "Records which Instagram screen you are on (screen names and view IDs only, " +
                "no message text). Turn on, do ONE thing in Instagram, come back, tap Copy."))
        captureInfo = TextView(this).apply {
            textSize = 12f
            setPadding(0, dp(4), 0, dp(4))
        }
        column.addView(captureInfo)
        column.addView(Button(this).apply {
            text = "Copy capture log"
            setOnClickListener { copyLog() }
        })
        column.addView(Button(this).apply {
            text = "Clear capture log"
            setOnClickListener {
                LogStore.clear(this@MainActivity)
                refreshCaptureInfo()
                Toast.makeText(this@MainActivity, "Cleared", Toast.LENGTH_SHORT).show()
            }
        })

        setContentView(ScrollView(this).apply { addView(column) })
    }

    override fun onResume() {
        super.onResume()
        val on = isServiceEnabled()
        statusText.text = if (on) "Blocker is ON" else "Blocker is OFF"
        enableButton.text = if (on) "Open accessibility settings" else "Turn on in accessibility settings"
        refreshCaptureInfo()
    }

    private fun refreshCaptureInfo() {
        val n = LogStore.read(this).length
        captureInfo.text = if (n == 0) "Log is empty." else "Log size: $n characters."
    }

    private fun copyLog() {
        val text = LogStore.read(this)
        if (text.isEmpty()) {
            Toast.makeText(this, "Nothing captured yet", Toast.LENGTH_SHORT).show()
            return
        }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Reels Blocker capture", text))
        Toast.makeText(this, "Copied ${text.length} characters", Toast.LENGTH_SHORT).show()
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val me = ComponentName(this, BlockerService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(me, ignoreCase = true) }
    }

    private fun toggle(label: String, key: String, hint: String?): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        box.addView(Switch(this).apply {
            text = label
            isChecked = Prefs.flag(this@MainActivity, key)
            setOnCheckedChangeListener { _, checked ->
                Prefs.get(this@MainActivity).edit().putBoolean(key, checked).apply()
            }
        })
        if (hint != null) {
            box.addView(TextView(this).apply {
                text = hint
                textSize = 12f
                gravity = Gravity.START
            })
        }
        return box
    }

    private fun sectionLabel(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(24), 0, dp(4))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
