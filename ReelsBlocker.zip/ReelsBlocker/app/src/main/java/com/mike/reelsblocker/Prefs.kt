package com.mike.reelsblocker

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val FILE = "reels_blocker_prefs"

    const val BLOCK_REELS = "block_reels"
    const val BLOCK_EXPLORE = "block_explore"
    const val BLOCK_DM_REELS = "block_dm_reels"
    const val CAPTURE = "capture_mode"
    const val AUTO_FOLLOWING = "auto_following"
    const val BLACKOUT_HOME = "blackout_home"

    fun get(context: Context): SharedPreferences =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun flag(context: Context, key: String): Boolean {
        val default = when (key) {
            BLOCK_REELS, BLOCK_EXPLORE, AUTO_FOLLOWING, BLACKOUT_HOME -> true
            else -> false // DM/viewer blocking and capture mode are opt-in
        }
        return get(context).getBoolean(key, default)
    }
}
