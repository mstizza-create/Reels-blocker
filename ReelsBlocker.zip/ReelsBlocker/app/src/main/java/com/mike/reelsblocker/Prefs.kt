package com.mike.reelsblocker

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val FILE = "reels_blocker_prefs"

    const val BLOCK_REELS = "block_reels"
    const val BLOCK_EXPLORE = "block_explore"
    const val BLOCK_DM_REELS = "block_dm_reels"
    const val DEBUG_LOG = "debug_log"

    fun get(context: Context): SharedPreferences =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun flag(context: Context, key: String): Boolean {
        val default = when (key) {
            BLOCK_REELS, BLOCK_EXPLORE -> true
            else -> false // DM reel blocking and debug logging are opt-in
        }
        return get(context).getBoolean(key, default)
    }
}
