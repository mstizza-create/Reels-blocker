package com.mike.reelsblocker

import android.content.Context
import java.io.File

/** Tiny on-device log used by "Capture mode". Never leaves the phone unless you copy and paste it. */
object LogStore {
    private const val FILE = "capture.log"
    private const val MAX_CHARS = 120_000

    private fun file(context: Context) = File(context.filesDir, FILE)

    @Synchronized
    fun append(context: Context, text: String) {
        val f = file(context)
        f.appendText(text + "\n")
        if (f.length() > MAX_CHARS) {
            f.writeText(f.readText().takeLast(MAX_CHARS / 2))
        }
    }

    @Synchronized
    fun read(context: Context): String {
        val f = file(context)
        return if (f.exists()) f.readText() else ""
    }

    @Synchronized
    fun clear(context: Context) {
        file(context).delete()
    }
}
