package com.mike.reelsblocker

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Watches the Instagram app (and only Instagram, see accessibility_service_config.xml).
 *
 * When the Reels or Explore bottom tab becomes selected, it taps the Home tab instead.
 * The Messages (DM) screen and notifications are never touched.
 *
 * IMPORTANT: Instagram does not publish these view IDs and changes them between releases.
 * Turn on "Capture mode" in the app to record what Instagram's screens look like, then copy the
 * log from the app and use it to update the lists in [Targets].
 */
class BlockerService : AccessibilityService() {

    private object Targets {
        const val PKG = "com.instagram.android"

        // Bottom tab bar view IDs (resource names, without the package prefix).
        val HOME_TAB_IDS = listOf("feed_tab")
        val REELS_TAB_IDS = listOf("clips_tab")
        val EXPLORE_TAB_IDS = listOf("search_tab")

        // Fallbacks: content descriptions of the tabs (English UI). Matched as "starts with".
        val HOME_DESCS = listOf("Home")
        val REELS_DESCS = listOf("Reels")
        val EXPLORE_DESCS = listOf("Search and Explore", "Explore")

        // Full-screen reel player. If these exist but the tab bar does not, the user is in
        // a reel opened from somewhere else. Used only if the experimental switch is on.
        // NOTE: Instagram also uses "reel" internally for Stories, so this can misfire.
        val REEL_VIEWER_IDS = listOf("clips_viewer_view_pager", "clips_viewer_fragment_container")

        // Home feed switcher: tapping the logo opens a menu whose items are labelled
        // (found in capture: title_logo, context_menu_item_label).
        const val LOGO_ID = "title_logo"
        const val MENU_LABEL_ID = "context_menu_item_label"
        const val FOLLOWING_LABEL = "Following"

        // Home-feed blackout: views that belong to feed posts/reels (from capture).
        // Anything whose ID starts with "row_feed_" also counts.
        val POST_IDS = setOf("media_group", "video_container", "carousel_video_media_group",
            "media_option_button", "secondary_label")
        val TAB_BAR_IDS = listOf("feed_tab", "search_tab", "clips_tab", "direct_tab", "profile_tab")
        const val ACTION_BAR_ID = "action_bar_title_view"

        // Full-screen reel player opened from the feed (from capture): the pager plus top tabs.
        val FEED_REEL_PLAYER_IDS = listOf("clips_viewer_view_pager")
        val FEED_REEL_PLAYER_TOP_TABS = listOf("action_bar_tab_layout")
    }

    private enum class FollowingState { IDLE, WANT, MENU }

    private var lastActionAt = 0L

    // Auto-switch-to-Following state
    private var followingState = FollowingState.IDLE
    private var followingStateAt = 0L
    private var lastFollowingActionAt = 0L
    private var lastIgEventAt = 0L

    // Home-feed blackout state
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var overlayTop = -1
    private var overlayHeight = -1
    private var lastOverlayAt = 0L
    private val handler = Handler(Looper.getMainLooper())

    /** While the overlay is up, checks that Instagram is still the active app; hides it if not. */
    private val overlayWatchdog = object : Runnable {
        override fun run() {
            val r = rootInActiveWindow
            if (r == null || r.packageName?.toString() != Targets.PKG) {
                hideOverlay()
            } else {
                handler.postDelayed(this, WATCHDOG_MS)
            }
        }
    }

    // Capture-mode state
    private var lastCaptureAt = 0L
    private var lastIds: Set<String> = emptySet()
    private var lastSelected: String = ""

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i(TAG, "Service connected")
    }

    override fun onInterrupt() {
        hideOverlay()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        hideOverlay()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        hideOverlay()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.packageName?.toString() != Targets.PKG) return

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != Targets.PKG) return

        if (Prefs.flag(this, Prefs.CAPTURE)) {
            capture(event, root)
        }

        val now = SystemClock.elapsedRealtime()

        val messagesOnly = Prefs.flag(this, Prefs.MESSAGES_ONLY)

        // Once per fresh Instagram open, switch Home to the "Following" feed.
        // (Not needed in Messages-only mode, where Home is never shown.)
        if (!messagesOnly && Prefs.flag(this, Prefs.AUTO_FOLLOWING)) {
            if (now - lastIgEventAt > SESSION_GAP_MS) {
                followingState = FollowingState.WANT
                followingStateAt = now
            }
            lastIgEventAt = now
            if (handleFollowing(root, now)) return
        } else {
            lastIgEventAt = now
        }

        updateOverlay(root, now, event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)

        // Messages-only: if Home, Reels, Search or Profile is the selected tab, jump to Messages.
        if (messagesOnly && now - lastActionAt >= DEBOUNCE_MS && goToMessages(root)) {
            lastActionAt = now
            return
        }

        // Debounce: our own click triggers more events.
        if (now - lastActionAt < DEBOUNCE_MS) return

        val homeTab = findTab(root, Targets.HOME_TAB_IDS, Targets.HOME_DESCS)

        val blockReels = Prefs.flag(this, Prefs.BLOCK_REELS)
        val blockExplore = Prefs.flag(this, Prefs.BLOCK_EXPLORE)
        val blockDmReels = Prefs.flag(this, Prefs.BLOCK_DM_REELS)

        // Only fall back to matching tab names when the real tab bar can't be found by ID.
        // (Otherwise a profile's own "Reels" sub-tab would be mistaken for the main Reels tab.)
        val tabBarPresent = hasAnyId(root, Targets.TAB_BAR_IDS)

        // 1) Reels / Explore tab selected -> go Home.
        if (blockReels) {
            val reelsTab = findTab(
                root, Targets.REELS_TAB_IDS, Targets.REELS_DESCS, allowDescFallback = !tabBarPresent
            )
            if (reelsTab != null && reelsTab.isSelected) {
                lastActionAt = now
                goHome(homeTab)
                return
            }
            // Reel player opened from the feed: full screen, no tab bar, with the "Reels | Friends"
            // style top tabs. (Reels opened from a DM don't show those top tabs.)
            if (hasAnyId(root, Targets.FEED_REEL_PLAYER_IDS) &&
                hasAnyId(root, Targets.FEED_REEL_PLAYER_TOP_TABS)
            ) {
                lastActionAt = now
                performGlobalAction(GLOBAL_ACTION_BACK)
                return
            }
        }
        if (blockExplore) {
            val exploreTab = findTab(
                root, Targets.EXPLORE_TAB_IDS, Targets.EXPLORE_DESCS, allowDescFallback = !tabBarPresent
            )
            if (exploreTab != null && exploreTab.isSelected) {
                lastActionAt = now
                goHome(homeTab)
                return
            }
        }

        // 2) Best effort: a reel player open with no tab bar on screen.
        if (blockDmReels && homeTab == null && hasAnyId(root, Targets.REEL_VIEWER_IDS)) {
            lastActionAt = now
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    private fun goHome(homeTab: AccessibilityNodeInfo?) {
        if (homeTab != null && clickNodeOrParent(homeTab)) return
        // Couldn't find or click Home; step back instead.
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var hops = 0
        while (current != null && hops < 4) {
            if (current.isClickable && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }
            current = current.parent
            hops++
        }
        return false
    }

    /** Finds a tab by view ID first, then falls back to content description. */
    private fun findTab(
        root: AccessibilityNodeInfo,
        ids: List<String>,
        descs: List<String>,
        allowDescFallback: Boolean = true,
    ): AccessibilityNodeInfo? {
        for (id in ids) {
            val hits = root.findAccessibilityNodeInfosByViewId("${Targets.PKG}:id/$id")
            if (!hits.isNullOrEmpty()) return hits.first()
        }
        if (!allowDescFallback) return null
        return findByDescription(root, descs, depth = 0)
    }

    private fun findByDescription(
        node: AccessibilityNodeInfo,
        descs: List<String>,
        depth: Int,
    ): AccessibilityNodeInfo? {
        if (depth > MAX_DEPTH) return null
        val d = node.contentDescription?.toString()
        // Only consider tab-like nodes (clickable or selectable), to avoid matching random text.
        if (d != null && (node.isClickable || node.isSelected) &&
            descs.any { d.startsWith(it, ignoreCase = true) }
        ) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findByDescription(child, descs, depth + 1)
            if (found != null) return found
        }
        return null
    }

    private fun hasAnyId(root: AccessibilityNodeInfo, ids: List<String>): Boolean =
        ids.any { !root.findAccessibilityNodeInfosByViewId("${Targets.PKG}:id/$it").isNullOrEmpty() }

    // ---- Following feed -----------------------------------------------------------------
    //
    // Flow: wait for Home to be selected and the Instagram logo to be on screen, tap the logo
    // (opens the feed menu), then tap the "Following" item. If the Following feed is already
    // showing, the logo isn't on screen, so nothing happens and the request times out.

    /** Returns true if this event was used up by the Following flow. */
    private fun handleFollowing(root: AccessibilityNodeInfo, now: Long): Boolean {
        if (followingState == FollowingState.IDLE) return false

        if (followingState == FollowingState.WANT) {
            if (now - followingStateAt > WANT_TIMEOUT_MS) {
                followingState = FollowingState.IDLE
                return false
            }
            if (now - lastFollowingActionAt < FOLLOWING_STEP_MS) return false
            val homeTab = findTab(root, Targets.HOME_TAB_IDS, Targets.HOME_DESCS)
            val logo = root.findAccessibilityNodeInfosByViewId("${Targets.PKG}:id/${Targets.LOGO_ID}")
                ?.firstOrNull()
            if (homeTab != null && homeTab.isSelected && logo != null && clickNodeOrParent(logo)) {
                followingState = FollowingState.MENU
                followingStateAt = now
                lastFollowingActionAt = now
                return true
            }
            return false
        }

        // MENU: the feed menu should be open; find and tap "Following".
        if (now - followingStateAt > MENU_TIMEOUT_MS) {
            followingState = FollowingState.IDLE
            return false
        }
        val labels = root.findAccessibilityNodeInfosByViewId("${Targets.PKG}:id/${Targets.MENU_LABEL_ID}")
        val item = labels?.firstOrNull {
            it.text?.toString()?.trim().equals(Targets.FOLLOWING_LABEL, ignoreCase = true)
        }
        if (item != null) {
            clickNodeOrParent(item)
            followingState = FollowingState.IDLE
            lastFollowingActionAt = now
            return true
        }
        return false
    }

    // ---- Messages only ------------------------------------------------------------------

    /**
     * If one of the other bottom tabs is selected, taps the Messages tab. Does nothing when no
     * other tab is selected (e.g. inside a conversation), so it can't loop on the Messages tab.
     */
    private fun goToMessages(root: AccessibilityNodeInfo): Boolean {
        val otherTabs = listOf("feed_tab", "search_tab", "clips_tab", "profile_tab")
        val otherSelected = otherTabs.any { id ->
            root.findAccessibilityNodeInfosByViewId("${Targets.PKG}:id/$id")?.any { it.isSelected } == true
        }
        if (!otherSelected) return false
        val direct = root.findAccessibilityNodeInfosByViewId("${Targets.PKG}:id/direct_tab")
            ?.firstOrNull() ?: return false
        return clickNodeOrParent(direct)
    }

    // ---- Home feed blackout -------------------------------------------------------------
    //
    // On the normal Home feed (not Following), draws a black, touch-through layer from the top of
    // the first visible post down to the tab bar. The story row sits above the first post, so it
    // stays visible. The layer hides itself whenever Instagram is not the active app.

    private fun updateOverlay(root: AccessibilityNodeInfo, now: Long, force: Boolean) {
        if (!Prefs.flag(this, Prefs.BLACKOUT_HOME) || Prefs.flag(this, Prefs.MESSAGES_ONLY)) {
            hideOverlay()
            return
        }
        if (!force && now - lastOverlayAt < OVERLAY_THROTTLE_MS) return
        lastOverlayAt = now

        val homeTab = findTab(root, Targets.HOME_TAB_IDS, Targets.HOME_DESCS)
        val logo = root.findAccessibilityNodeInfosByViewId("${Targets.PKG}:id/${Targets.LOGO_ID}")
            ?.firstOrNull()
        // Only on the normal Home feed: Home tab selected and the Instagram logo showing.
        if (homeTab == null || !homeTab.isSelected || logo == null) {
            hideOverlay()
            return
        }

        val postTop = minPostTop(root, 0)
        if (postTop == Int.MAX_VALUE) { // no posts on screen yet
            hideOverlay()
            return
        }

        val bar = root.findAccessibilityNodeInfosByViewId("${Targets.PKG}:id/${Targets.ACTION_BAR_ID}")
            ?.firstOrNull() ?: logo
        val barRect = Rect()
        bar.getBoundsInScreen(barRect)

        val tabTop = tabBarTop(root)
        if (tabTop == Int.MAX_VALUE) {
            hideOverlay()
            return
        }

        val top = maxOf(postTop, barRect.bottom)
        val height = tabTop - top
        if (height <= 0) {
            hideOverlay()
            return
        }
        showOverlay(top, height)
    }

    /** Top edge of the highest visible feed-post view, or Int.MAX_VALUE if none. */
    private fun minPostTop(node: AccessibilityNodeInfo, depth: Int): Int {
        if (depth > MAX_DEPTH) return Int.MAX_VALUE
        var best = Int.MAX_VALUE
        val id = node.viewIdResourceName?.substringAfter(":id/")
        if (id != null && node.isVisibleToUser &&
            (id.startsWith("row_feed_") || id in Targets.POST_IDS)
        ) {
            val r = Rect()
            node.getBoundsInScreen(r)
            if (r.width() > 0 && r.height() > 0) best = r.top
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            best = minOf(best, minPostTop(child, depth + 1))
        }
        return best
    }

    /** Top edge of the bottom tab bar, or Int.MAX_VALUE if it can't be found. */
    private fun tabBarTop(root: AccessibilityNodeInfo): Int {
        var top = Int.MAX_VALUE
        val maxBarHeight = (120 * resources.displayMetrics.density).toInt()
        for (id in Targets.TAB_BAR_IDS) {
            val nodes = root.findAccessibilityNodeInfosByViewId("${Targets.PKG}:id/$id") ?: continue
            for (n in nodes) {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.height() > 0) top = minOf(top, r.top)
                val p = n.parent
                if (p != null) {
                    val pr = Rect()
                    p.getBoundsInScreen(pr)
                    // The parent is probably the bar itself; only trust it if it's bar-sized.
                    if (pr.height() in 1..maxBarHeight) top = minOf(top, pr.top)
                }
            }
        }
        return top
    }

    private fun showOverlay(top: Int, height: Int) {
        try {
            val wm = windowManager
                ?: (getSystemService(WINDOW_SERVICE) as WindowManager).also { windowManager = it }
            val view = overlayView
            if (view == null) {
                val v = View(this).apply { setBackgroundColor(Color.BLACK) }
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    height,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.OPAQUE,
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = 0
                    y = top
                }
                wm.addView(v, lp)
                overlayView = v
                handler.removeCallbacks(overlayWatchdog)
                handler.postDelayed(overlayWatchdog, WATCHDOG_MS)
            } else if (top != overlayTop || height != overlayHeight) {
                val lp = view.layoutParams as WindowManager.LayoutParams
                lp.y = top
                lp.height = height
                wm.updateViewLayout(view, lp)
            }
            overlayTop = top
            overlayHeight = height
        } catch (e: Exception) {
            Log.w(TAG, "Overlay failed: ${e.message}")
        }
    }

    private fun hideOverlay() {
        handler.removeCallbacks(overlayWatchdog)
        val view = overlayView ?: return
        try {
            windowManager?.removeView(view)
        } catch (e: Exception) {
            Log.w(TAG, "Overlay remove failed: ${e.message}")
        }
        overlayView = null
        overlayTop = -1
        overlayHeight = -1
    }

    // ---- Capture mode -------------------------------------------------------------------
    //
    // Records, whenever Instagram's screen changes: the screen class name, which view IDs
    // appeared/disappeared, and which views are "selected" (e.g. the current tab).
    // It does NOT record message text, captions or usernames; only view IDs and tab names.
    // The log stays on the phone until you copy it yourself from the app.

    private fun capture(event: AccessibilityEvent, root: AccessibilityNodeInfo) {
        val now = SystemClock.elapsedRealtime()
        val isWindowChange = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        if (!isWindowChange && now - lastCaptureAt < CAPTURE_THROTTLE_MS) return
        lastCaptureAt = now

        val ids = sortedSetOf<String>()
        val selected = sortedSetOf<String>()
        collect(root, 0, ids, selected)

        val selectedSig = selected.joinToString(", ")
        val added = ids - lastIds
        val removed = lastIds - ids
        if (!isWindowChange && added.isEmpty() && removed.isEmpty() && selectedSig == lastSelected) return

        val sb = StringBuilder()
        sb.append('[').append(TIME_FORMAT.format(Date())).append("] ")
            .append(eventName(event.eventType))
        event.className?.let { sb.append(" class=").append(it) }
        sb.append('\n')
        if (added.isNotEmpty()) sb.append("  +ids: ").append(added.joinToString(" ")).append('\n')
        if (removed.isNotEmpty()) sb.append("  -ids: ").append(removed.joinToString(" ")).append('\n')
        sb.append("  selected: ").append(if (selectedSig.isEmpty()) "(none)" else selectedSig)

        LogStore.append(this, sb.toString())
        lastIds = ids
        lastSelected = selectedSig
    }

    private fun collect(
        node: AccessibilityNodeInfo,
        depth: Int,
        ids: MutableSet<String>,
        selected: MutableSet<String>,
    ) {
        if (depth > MAX_DEPTH) return
        val id = node.viewIdResourceName?.substringAfter(":id/")
        if (id != null) ids.add(id)
        if (node.isSelected) {
            val desc = node.contentDescription?.toString()?.take(30)
            selected.add(
                when {
                    id != null && desc != null -> "$id|$desc"
                    id != null -> id
                    desc != null -> "|$desc"
                    else -> "(unnamed)"
                }
            )
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collect(it, depth + 1, ids, selected) }
        }
    }

    private fun eventName(type: Int) = when (type) {
        AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> "WINDOW"
        AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> "CONTENT"
        AccessibilityEvent.TYPE_VIEW_SELECTED -> "SELECTED"
        AccessibilityEvent.TYPE_VIEW_CLICKED -> "CLICKED"
        else -> "EVENT$type"
    }

    companion object {
        private const val TAG = "ReelsBlocker"
        private const val DEBOUNCE_MS = 500L
        private const val SESSION_GAP_MS = 45_000L   // quiet this long = treated as a fresh open
        private const val WANT_TIMEOUT_MS = 10_000L  // how long to wait for Home to appear
        private const val MENU_TIMEOUT_MS = 4_000L   // how long to wait for the feed menu
        private const val FOLLOWING_STEP_MS = 400L
        private const val OVERLAY_THROTTLE_MS = 80L
        private const val WATCHDOG_MS = 600L
        private const val CAPTURE_THROTTLE_MS = 300L
        private const val MAX_DEPTH = 30
        private val TIME_FORMAT = SimpleDateFormat("HH:mm:ss", Locale.US)
    }
}
