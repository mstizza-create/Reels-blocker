package com.mike.reelsblocker

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Watches the Instagram app (and only Instagram, see accessibility_service_config.xml).
 *
 * When the Reels or Explore bottom tab becomes selected, it taps the Home tab instead.
 * The Messages (DM) screen and notifications are never touched.
 *
 * IMPORTANT: Instagram does not publish these view IDs and changes them between releases.
 * If blocking stops working after an Instagram update, turn on "Debug logging" in the app,
 * open Instagram, run `adb logcat -s ReelsBlocker`, and update the lists in [Targets].
 */
class BlockerService : AccessibilityService() {

    private object Targets {
        const val PKG = "com.instagram.android"

        // Bottom tab bar view IDs (resource names, without the package prefix).
        val HOME_TAB_IDS = listOf("feed_tab")
        val REELS_TAB_IDS = listOf("clips_tab")
        val EXPLORE_TAB_IDS = listOf("search_tab")

        // Fallbacks: content descriptions of the tabs (English UI). Matched as "starts with".
        val HOME_DESCS = listOf("Home")
        val REELS_DESCS = listOf("Reels")
        val EXPLORE_DESCS = listOf("Search and Explore", "Explore")

        // Full-screen reel player. If these exist but the tab bar does not, the user is in
        // a reel opened from somewhere else (e.g. a DM). Used only if "Block reels from DMs" is on.
        val REEL_VIEWER_IDS = listOf("clips_viewer_view_pager", "clips_viewer_fragment_container")
    }

    private var lastActionAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i(TAG, "Service connected")
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.packageName?.toString() != Targets.PKG) return

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != Targets.PKG) return

        if (Prefs.flag(this, Prefs.DEBUG_LOG) &&
            event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        ) {
            dumpTree(root)
        }

        // Debounce: our own click triggers more events.
        val now = SystemClock.elapsedRealtime()
        if (now - lastActionAt < DEBOUNCE_MS) return

        val homeTab = findTab(root, Targets.HOME_TAB_IDS, Targets.HOME_DESCS)

        val blockReels = Prefs.flag(this, Prefs.BLOCK_REELS)
        val blockExplore = Prefs.flag(this, Prefs.BLOCK_EXPLORE)
        val blockDmReels = Prefs.flag(this, Prefs.BLOCK_DM_REELS)

        // 1) Reels / Explore tab selected -> go Home.
        if (blockReels) {
            val reelsTab = findTab(root, Targets.REELS_TAB_IDS, Targets.REELS_DESCS)
            if (reelsTab != null && reelsTab.isSelected) {
                lastActionAt = now
                goHome(homeTab)
                return
            }
        }
        if (blockExplore) {
            val exploreTab = findTab(root, Targets.EXPLORE_TAB_IDS, Targets.EXPLORE_DESCS)
            if (exploreTab != null && exploreTab.isSelected) {
                lastActionAt = now
                goHome(homeTab)
                return
            }
        }

        // 2) Best effort: a reel player open with no tab bar on screen (e.g. opened from a DM).
        if (blockDmReels && homeTab == null && hasAnyId(root, Targets.REEL_VIEWER_IDS)) {
            lastActionAt = now
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    private fun goHome(homeTab: AccessibilityNodeInfo?) {
        if (homeTab != null && clickNodeOrParent(homeTab)) return
        // Couldn't find or click Home; step back instead.
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var hops = 0
        while (current != null && hops < 4) {
            if (current.isClickable && current.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }
            current = current.parent
            hops++
        }
        return false
    }

    /** Finds a tab by view ID first, then falls back to content description. */
    private fun findTab(
        root: AccessibilityNodeInfo,
        ids: List<String>,
        descs: List<String>,
    ): AccessibilityNodeInfo? {
        for (id in ids) {
            val hits = root.findAccessibilityNodeInfosByViewId("${Targets.PKG}:id/$id")
            if (!hits.isNullOrEmpty()) return hits.first()
        }
        return findByDescription(root, descs, depth = 0)
    }

    private fun findByDescription(
        node: AccessibilityNodeInfo,
        descs: List<String>,
        depth: Int,
    ): AccessibilityNodeInfo? {
        if (depth > MAX_DEPTH) return null
        val d = node.contentDescription?.toString()
        // Only consider tab-like nodes (clickable or selectable), to avoid matching random text.
        if (d != null && (node.isClickable || node.isSelected) &&
            descs.any { d.startsWith(it, ignoreCase = true) }
        ) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findByDescription(child, descs, depth + 1)
            if (found != null) return found
        }
        return null
    }

    private fun hasAnyId(root: AccessibilityNodeInfo, ids: List<String>): Boolean =
        ids.any { !root.findAccessibilityNodeInfosByViewId("${Targets.PKG}:id/$it").isNullOrEmpty() }

    // ---- Debug helper -------------------------------------------------------------------

    private fun dumpTree(root: AccessibilityNodeInfo) {
        val sb = StringBuilder("\n--- Instagram UI tree ---\n")
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (depth > MAX_DEPTH) return
            val id = n.viewIdResourceName?.substringAfter(":id/") ?: "-"
            val desc = n.contentDescription ?: ""
            if (id != "-" || desc.isNotEmpty()) {
                sb.append("  ".repeat(depth))
                    .append("id=").append(id)
                    .append(" desc=\"").append(desc).append("\"")
                    .append(" sel=").append(n.isSelected)
                    .append(" click=").append(n.isClickable)
                    .append('\n')
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, depth + 1) }
        }
        walk(root, 0)
        Log.d(TAG, sb.toString())
    }

    companion object {
        private const val TAG = "ReelsBlocker"
        private const val DEBOUNCE_MS = 500L
        private const val MAX_DEPTH = 30
    }
}
