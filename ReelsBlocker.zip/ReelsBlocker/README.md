# Reels Blocker

A tiny Android app that removes Instagram's Reels and Explore tabs from your day while leaving
messages and notifications alone. It works like SocialLite's Android mode: an Accessibility
Service that watches the Instagram app and taps **Home** whenever Reels or Explore is selected.

No internet permission, no analytics, no data stored. It only sees Instagram's screen (the service is
scoped to `com.instagram.android`).

## Build and install

1. Install **Android Studio** (current stable) on a computer.
2. **File → Open** and choose this `ReelsBlocker` folder. Let Gradle sync
   (accept any prompt to download Gradle or upgrade the Android Gradle Plugin).
3. On your phone: **Settings → About phone**, tap *Build number* 7 times, then
   **Developer options → USB debugging** on. Plug the phone in and approve the prompt.
4. Press **Run ▶** in Android Studio with your phone selected.
   (Or **Build → Build APK(s)** and copy the APK across.)

## Turn it on

1. Open **Reels Blocker** and tap *Turn on in accessibility settings*.
2. Find **Reels Blocker** in the list and switch it on.

**If the switch is greyed out ("Restricted setting")** — Android 13+ does this for apps installed from an
APK file. Go to **Settings → Apps → Reels Blocker → ⋮ (top right) → Allow restricted settings**, then retry.
Installing straight from Android Studio usually avoids this.

## Settings in the app

| Toggle | Default | What it does |
|---|---|---|
| Reels tab | On | Reels tab selected → jump to Home |
| Explore tab | On | Explore tab selected → jump to Home (this also stops searching new accounts via Explore) |
| Reels opened from messages | Off | Experimental: presses Back when a full-screen reel player is open with no tab bar |
| Debug logging | Off | Logs Instagram's tab IDs for fixing the rules |

## When Instagram updates and blocking stops working

Instagram's internal view IDs aren't public and change. The matching rules are in one place:
`app/src/main/java/com/mike/reelsblocker/BlockerService.kt`, in the `Targets` object.

1. Turn on **Debug logging** in the app.
2. With the phone plugged in, run `adb logcat -s ReelsBlocker` and open Instagram.
3. Find the line for the bottom tab bar (the Home / Search / Reels / Messages / Profile entries,
   with `sel=true` on the current tab) and copy the new `id=` values into `HOME_TAB_IDS`,
   `REELS_TAB_IDS`, `EXPLORE_TAB_IDS`.
4. Re-run from Android Studio.

The description-based fallback ("Reels", "Home", "Search and Explore") needs an English UI language.
Edit `*_DESCS` if your phone is set to another language.

## Known limits

- It reacts after the tab opens, so you may see a brief flash of Reels before it bounces you to Home.
- Reels sent to you in DMs open in a player; the experimental toggle handles this imperfectly.
- Instagram's other reel surfaces (profile Reels grid, shared reels) are not blocked unless the experimental toggle is on.
- Accessibility services can be disabled by you at any time in Settings. That is the intended off switch.
